function i = argmax(x,varargin)

[nothing,i] = max(x,varargin{:});