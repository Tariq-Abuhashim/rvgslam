function i = argmin(x,varargin)

[nothing,i] = min(x,varargin{:});